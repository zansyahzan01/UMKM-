import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        // Sambeliler Brand Colors - Natural & Ethnic
        earth: {
          50: "#faf8f3",
          100: "#f4f0e6",
          200: "#e8ddc6",
          300: "#dbc5a0",
          400: "#cba872",
          500: "#b8934f",
          600: "#a17d42",
          700: "#856738",
          800: "#6d5330",
          900: "#574229",
        },
        forest: {
          50: "#f1f8f0",
          100: "#dcefe0",
          200: "#bcdfc4",
          300: "#8cc79a",
          400: "#5ca66b",
          500: "#3e8749",
          600: "#2e6d37",
          700: "#26562d",
          800: "#214527",
          900: "#1c3922",
        },
        cream: {
          50: "#fefcf8",
          100: "#fdf8ec",
          200: "#faf0d3",
          300: "#f5e4b0",
          400: "#efd485",
          500: "#e6c062",
          600: "#d3a749",
          700: "#b08a3d",
          800: "#8f6f37",
          900: "#765c31",
        },
        batik: {
          50: "#f8f5f0",
          100: "#f0e7d6",
          200: "#e0cfad",
          300: "#ccb07a",
          400: "#ba9352",
          500: "#a67c3a",
          600: "#8f662f",
          700: "#744f28",
          800: "#614227",
          900: "#533725",
        },
        // Shadcn compatibility colors
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
        },
      },
      fontFamily: {
        serif: ["Playfair Display", "serif"],
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;
