import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const PackagingMockup: React.FC = () => {
  const [selectedBag, setSelectedBag] = useState<number | null>(null);
  const [showHangtag, setShowHangtag] = useState(false);

  const bags = [
    {
      id: 1,
      name: "Tas Goni Batik Klasik",
      pattern: "batik",
      color: "earth-600",
      description:
        "Tas dari bahan goni berkualitas dengan motif batik tradisional",
    },
    {
      id: 2,
      name: "Tas Lurik Modern",
      pattern: "lurik",
      color: "forest-600",
      description:
        "Perpaduan sempurna antara kain lurik dan bahan goni ramah lingkungan",
    },
    {
      id: 3,
      name: "Tas Tenun Nusantara",
      pattern: "tenun",
      color: "batik-600",
      description:
        "Tas eksklusif dengan kain tenun asli Nusantara dan finishing premium",
    },
  ];

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-earth-800 mb-4">
          Kemasan Produk Sambeliler
        </h2>
        <p className="text-lg text-forest-700 max-w-2xl mx-auto">
          Setiap tas dikemas dengan perhatian detail, menggunakan bahan ramah
          lingkungan dan dilengkapi hangtag berisi petunjuk perawatan
        </p>
      </div>

      {/* Product Bags Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        {bags.map((bag) => (
          <motion.div
            key={bag.id}
            className="relative cursor-pointer group"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setSelectedBag(bag.id)}
          >
            {/* Kraft Paper Background */}
            <div className="bg-gradient-to-br from-cream-100 to-cream-200 rounded-lg p-6 shadow-lg border border-cream-300">
              {/* Bag Mockup */}
              <div className="relative">
                <svg
                  className="w-full h-48 mb-4"
                  viewBox="0 0 200 200"
                  fill="none"
                >
                  {/* Bag shadow */}
                  <ellipse
                    cx="100"
                    cy="190"
                    rx="60"
                    ry="8"
                    fill="#000000"
                    opacity="0.1"
                  />

                  {/* Main bag body */}
                  <rect
                    x="60"
                    y="80"
                    width="80"
                    height="100"
                    fill={`var(--color-${bag.color})`}
                    stroke="#856738"
                    strokeWidth="2"
                    rx="4"
                  />

                  {/* Bag pattern based on type */}
                  {bag.pattern === "batik" && (
                    <g>
                      <circle
                        cx="80"
                        cy="110"
                        r="3"
                        fill="#a67c3a"
                        opacity="0.6"
                      />
                      <circle
                        cx="120"
                        cy="130"
                        r="3"
                        fill="#a67c3a"
                        opacity="0.6"
                      />
                      <circle
                        cx="100"
                        cy="150"
                        r="2"
                        fill="#b8934f"
                        opacity="0.7"
                      />
                      <path
                        d="M70 100 Q85 95 100 100 Q115 105 130 100"
                        stroke="#744f28"
                        strokeWidth="1"
                        fill="none"
                        opacity="0.5"
                      />
                    </g>
                  )}

                  {bag.pattern === "lurik" && (
                    <g>
                      <rect
                        x="62"
                        y="90"
                        width="76"
                        height="2"
                        fill="#2e6d37"
                        opacity="0.6"
                      />
                      <rect
                        x="62"
                        y="100"
                        width="76"
                        height="2"
                        fill="#2e6d37"
                        opacity="0.6"
                      />
                      <rect
                        x="62"
                        y="110"
                        width="76"
                        height="2"
                        fill="#2e6d37"
                        opacity="0.6"
                      />
                      <rect
                        x="62"
                        y="120"
                        width="76"
                        height="2"
                        fill="#2e6d37"
                        opacity="0.6"
                      />
                      <rect
                        x="62"
                        y="130"
                        width="76"
                        height="2"
                        fill="#2e6d37"
                        opacity="0.6"
                      />
                    </g>
                  )}

                  {bag.pattern === "tenun" && (
                    <g>
                      <rect
                        x="75"
                        y="85"
                        width="2"
                        height="90"
                        fill="#8f662f"
                        opacity="0.6"
                      />
                      <rect
                        x="85"
                        y="85"
                        width="2"
                        height="90"
                        fill="#8f662f"
                        opacity="0.6"
                      />
                      <rect
                        x="95"
                        y="85"
                        width="2"
                        height="90"
                        fill="#8f662f"
                        opacity="0.6"
                      />
                      <rect
                        x="105"
                        y="85"
                        width="2"
                        height="90"
                        fill="#8f662f"
                        opacity="0.6"
                      />
                      <rect
                        x="115"
                        y="85"
                        width="2"
                        height="90"
                        fill="#8f662f"
                        opacity="0.6"
                      />
                      <rect
                        x="125"
                        y="85"
                        width="2"
                        height="90"
                        fill="#8f662f"
                        opacity="0.6"
                      />
                    </g>
                  )}

                  {/* Bag handles */}
                  <path
                    d="M80 80 C80 70, 85 65, 90 65 L110 65 C115 65, 120 70, 120 80"
                    stroke="#856738"
                    strokeWidth="4"
                    fill="none"
                  />

                  {/* Hangtag */}
                  <rect
                    x="130"
                    y="70"
                    width="20"
                    height="25"
                    fill="#faf8f3"
                    stroke="#b8934f"
                    strokeWidth="1"
                    rx="2"
                  />
                  <line
                    x1="135"
                    y1="75"
                    x2="145"
                    y2="75"
                    stroke="#cba872"
                    strokeWidth="1"
                  />
                  <line
                    x1="135"
                    y1="80"
                    x2="145"
                    y2="80"
                    stroke="#cba872"
                    strokeWidth="1"
                  />
                  <line
                    x1="135"
                    y1="85"
                    x2="145"
                    y2="85"
                    stroke="#cba872"
                    strokeWidth="1"
                  />
                  <line
                    x1="125"
                    y1="75"
                    x2="130"
                    y2="75"
                    stroke="#856738"
                    strokeWidth="2"
                  />
                </svg>

                {/* Product info */}
                <h3 className="text-lg font-semibold text-earth-800 mb-2">
                  {bag.name}
                </h3>
                <p className="text-sm text-forest-600 mb-4">
                  {bag.description}
                </p>

                {/* Click indicator */}
                <div className="absolute top-2 right-2 bg-forest-500 text-white px-2 py-1 rounded-full text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                  Klik untuk detail
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Hangtag Detail Button */}
      <div className="text-center">
        <motion.button
          onClick={() => setShowHangtag(true)}
          className="bg-forest-600 hover:bg-forest-700 text-white px-8 py-3 rounded-lg font-semibold shadow-lg transition-colors"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Lihat Detail Hangtag
        </motion.button>
      </div>

      {/* Hangtag Modal */}
      <AnimatePresence>
        {showHangtag && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowHangtag(false)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-cream-50 rounded-lg p-8 max-w-md w-full shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Hangtag Header */}
              <div className="text-center mb-6">
                <div className="w-16 h-20 bg-cream-100 border-2 border-earth-400 rounded-lg mx-auto mb-4 relative">
                  <div className="absolute top-2 left-2 right-2 h-1 bg-earth-300 rounded"></div>
                  <div className="absolute top-5 left-2 right-2 h-0.5 bg-earth-300 rounded"></div>
                  <div className="absolute top-7 left-2 right-2 h-0.5 bg-earth-300 rounded"></div>
                  <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 border-2 border-earth-400 rounded-full bg-cream-50"></div>
                </div>
                <h3 className="text-xl font-bold text-earth-800">
                  Petunjuk Perawatan
                </h3>
                <p className="text-sm text-forest-600">Tas Etnik Sambeliler</p>
              </div>

              {/* Care Instructions */}
              <div className="space-y-4 text-sm text-earth-700">
                <div className="flex items-start space-x-3">
                  <span className="text-forest-600 font-bold">1.</span>
                  <span>
                    Hindari terkena air berlebihan. Jika basah, keringkan segera
                    di tempat teduh.
                  </span>
                </div>
                <div className="flex items-start space-x-3">
                  <span className="text-forest-600 font-bold">2.</span>
                  <span>
                    Untuk membersihkan, gunakan kain lembab dan sabun ringan.
                  </span>
                </div>
                <div className="flex items-start space-x-3">
                  <span className="text-forest-600 font-bold">3.</span>
                  <span>
                    Simpan di tempat kering dan gunakan silica gel untuk
                    menyerap kelembaban.
                  </span>
                </div>
                <div className="flex items-start space-x-3">
                  <span className="text-forest-600 font-bold">4.</span>
                  <span>Jangan gunakan pemutih atau bahan kimia keras.</span>
                </div>
                <div className="flex items-start space-x-3">
                  <span className="text-forest-600 font-bold">5.</span>
                  <span>Produk ramah lingkungan, dukung UMKM Indonesia!</span>
                </div>
              </div>

              {/* Close button */}
              <button
                onClick={() => setShowHangtag(false)}
                className="w-full mt-6 bg-earth-600 hover:bg-earth-700 text-white py-2 rounded-lg font-semibold transition-colors"
              >
                Tutup
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Selected Bag Detail */}
      <AnimatePresence>
        {selectedBag && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedBag(null)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-lg p-8 max-w-2xl w-full shadow-xl"
              onClick={(e) => e.stopPropagation()}
            >
              {bags.map(
                (bag) =>
                  bag.id === selectedBag && (
                    <div key={bag.id}>
                      <h3 className="text-2xl font-bold text-earth-800 mb-4">
                        {bag.name}
                      </h3>
                      <p className="text-forest-700 mb-6">{bag.description}</p>

                      <div className="bg-cream-50 p-6 rounded-lg">
                        <h4 className="font-semibold text-earth-800 mb-3">
                          Detail Produk:
                        </h4>
                        <ul className="space-y-2 text-earth-700">
                          <li>
                            • Material: Goni berkualitas tinggi + Kain etnik
                            Indonesia
                          </li>
                          <li>• Ukuran: 35cm x 40cm x 15cm</li>
                          <li>• Handle: Tali goni reinforced</li>
                          <li>• Finishing: Water resistant coating</li>
                          <li>• Kemasan: Kraft paper eco-friendly + hangtag</li>
                        </ul>
                      </div>

                      <button
                        onClick={() => setSelectedBag(null)}
                        className="w-full mt-6 bg-forest-600 hover:bg-forest-700 text-white py-3 rounded-lg font-semibold transition-colors"
                      >
                        Tutup Detail
                      </button>
                    </div>
                  ),
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PackagingMockup;
