import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import SambelilerLogo from "./SambelilerLogo";
import PackagingMockup from "./PackagingMockup";
import TestingInterface from "./TestingInterface";

interface DesignThinkingStagesProps {
  currentStage: number;
}

const DesignThinkingStages: React.FC<DesignThinkingStagesProps> = ({
  currentStage,
}) => {
  const [selectedMoodboardItem, setSelectedMoodboardItem] = useState<
    string | null
  >(null);

  const stageVariants = {
    initial: { opacity: 0, x: 100 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -100 },
  };

  // Stage 1: Empathize
  const EmpathizeStage = () => (
    <motion.div
      variants={stageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="min-h-screen py-16 px-6"
    >
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-earth-800 mb-6">
            🤝 Empathize
          </h2>
          <p className="text-xl text-forest-700 max-w-3xl mx-auto">
            Memahami masalah dan kebutuhan pengguna Sambeliler melalui riset dan
            observasi
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Problem 1: Logo Lama */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-red-50 border-2 border-red-200 rounded-xl p-6"
          >
            <div className="text-center mb-4">
              <div className="w-16 h-16 bg-red-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <p>👜</p>
              </div>
              <h3 className="text-xl font-semibold text-red-800 mb-3">
                Logo Terlalu Sederhana
              </h3>
            </div>

            {/* Mock old logo */}
            <div className="bg-white p-4 rounded-lg mb-4">
              <svg className="w-full h-24" viewBox="0 0 200 100">
                <rect
                  x="50"
                  y="30"
                  width="100"
                  height="40"
                  fill="#8B4513"
                  rx="5"
                />
                <text
                  x="100"
                  y="55"
                  textAnchor="middle"
                  fill="white"
                  fontSize="14"
                  fontFamily="Arial"
                >
                  SAMBELILER
                </text>
              </svg>
            </div>

            <ul className="text-red-700 space-y-2 text-sm">
              <li>• Tidak mencerminkan identitas etnik Indonesia</li>
              <li>• Warna monoton dan kurang menarik</li>
              <li>• Tidak ada elemen visual yang bercerita</li>
              <li>• Terkesan generik dan mudah dilupakan</li>
            </ul>
          </motion.div>

          {/* Problem 2: Kemasan */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-orange-50 border-2 border-orange-200 rounded-xl p-6"
          >
            <div className="text-center mb-4">
              <div className="w-16 h-16 bg-orange-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-2xl">📦</span>
              </div>
              <h3 className="text-xl font-semibold text-orange-800 mb-3">
                Kemasan Kurang Etnik
              </h3>
            </div>

            {/* Mock old packaging */}
            <div className="bg-white p-4 rounded-lg mb-4">
              <div className="w-full h-24 bg-gray-200 rounded border-2 border-gray-300 flex items-center justify-center">
                <span className="text-gray-500 text-sm">Kemasan Polos</span>
              </div>
            </div>

            <ul className="text-orange-700 space-y-2 text-sm">
              <li>• Tidak ada unsur budaya Indonesia</li>
              <li>• Material terkesan murah</li>
              <li>• Tidak eco-friendly branding</li>
              <li>• Kurang premium dan authentic</li>
            </ul>
          </motion.div>

          {/* Problem 3: Hangtag */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-yellow-50 border-2 border-yellow-200 rounded-xl p-6"
          >
            <div className="text-center mb-4">
              <div className="w-16 h-16 bg-yellow-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-2xl">🏷️</span>
              </div>
              <h3 className="text-xl font-semibold text-yellow-800 mb-3">
                Tidak Ada Hangtag
              </h3>
            </div>

            {/* Empty hangtag space */}
            <div className="bg-white p-4 rounded-lg mb-4 border-2 border-dashed border-gray-300">
              <div className="text-center text-gray-400 py-4">
                <span className="text-sm">Tidak ada hangtag</span>
              </div>
            </div>

            <ul className="text-yellow-700 space-y-2 text-sm">
              <li>• Tidak ada petunjuk perawatan</li>
              <li>• Informasi produk minim</li>
              <li>• Tidak ada brand storytelling</li>
              <li>• Kehilangan peluang edukasi konsumen</li>
            </ul>
          </motion.div>
        </div>

        {/* User Insights */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mt-12 bg-gradient-to-r from-earth-50 to-forest-50 rounded-2xl p-8"
        >
          <h3 className="text-2xl font-bold text-earth-800 mb-6 text-center">
            💭 Insight Pengguna
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h4 className="font-semibold text-earth-800 mb-3">
                Target Konsumen
              </h4>
              <ul className="text-earth-700 space-y-2">
                <li>• Wanita urban usia 25-45 tahun</li>
                <li>• Peduli lingkungan dan sustainability</li>
                <li>• Menghargai produk lokal dan handcraft</li>
                <li>• Aktif di media sosial</li>
              </ul>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h4 className="font-semibold text-earth-800 mb-3">Pain Points</h4>
              <ul className="text-earth-700 space-y-2">
                <li>• Sulit merawat tas berbahan alami</li>
                <li>• Ingin produk yang Instagram-able</li>
                <li>• Butuh jaminan kualitas produk UMKM</li>
                <li>• Ingin tahu story di balik produk</li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );

  // Stage 2: Define
  const DefineStage = () => (
    <motion.div
      variants={stageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="min-h-screen py-16 px-6"
    >
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-earth-800 mb-6">
            🎯 Define
          </h2>
          <p className="text-xl text-forest-700 max-w-3xl mx-auto">
            Mendefinisikan tujuan desain berdasarkan insight yang diperoleh dari
            tahap empathize
          </p>
        </div>

        {/* Problem Statement */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-r from-red-50 to-orange-50 border-2 border-red-200 rounded-2xl p-8 mb-8"
        >
          <h3 className="text-2xl font-bold text-red-800 mb-4 text-center">
            🚨 Problem Statement
          </h3>
          <p className="text-lg text-red-700 text-center italic">
            "Sambeliler membutuhkan identitas visual yang kuat untuk
            mengkomunikasikan nilai-nilai tradisional Indonesia, kualitas
            premium, dan komitmen terhadap lingkungan kepada target konsumen
            urban yang peduli sustainability."
          </p>
        </motion.div>

        {/* Design Objectives */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-forest-50 border-2 border-forest-200 rounded-xl p-6"
          >
            <div className="text-center mb-4">
              <div className="w-16 h-16 bg-forest-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-2xl">🎨</span>
              </div>
              <h3 className="text-xl font-semibold text-forest-800 mb-3">
                Objective 1: Logo Baru
              </h3>
            </div>
            <ul className="text-forest-700 space-y-2 text-sm">
              <li>✓ Mengintegrasikan motif batik/lurik/tenun</li>
              <li>✓ Menggunakan palet warna alam</li>
              <li>✓ Modern minimalis namun tetap etnik</li>
              <li>✓ Mudah diaplikasikan di berbagai media</li>
              <li>✓ Memorable dan distinctive</li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-earth-50 border-2 border-earth-200 rounded-xl p-6"
          >
            <div className="text-center mb-4">
              <div className="w-16 h-16 bg-earth-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-2xl">📦</span>
              </div>
              <h3 className="text-xl font-semibold text-earth-800 mb-3">
                Objective 2: Kemasan Premium
              </h3>
            </div>
            <ul className="text-earth-700 space-y-2 text-sm">
              <li>✓ Material ramah lingkungan (kraft paper)</li>
              <li>✓ Desain yang Instagram-able</li>
              <li>✓ Mencerminkan kualitas premium</li>
              <li>✓ Konsisten dengan brand identity</li>
              <li>✓ Functional dan protective</li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8 }}
            className="bg-batik-50 border-2 border-batik-200 rounded-xl p-6"
          >
            <div className="text-center mb-4">
              <div className="w-16 h-16 bg-batik-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-2xl">🏷️</span>
              </div>
              <h3 className="text-xl font-semibold text-batik-800 mb-3">
                Objective 3: Hangtag Informatif
              </h3>
            </div>
            <ul className="text-batik-700 space-y-2 text-sm">
              <li>✓ Petunjuk perawatan yang jelas</li>
              <li>✓ Brand story dan nilai-nilai</li>
              <li>✓ Informasi material dan kualitas</li>
              <li>✓ QR code untuk digital engagement</li>
              <li>✓ Desain yang premium dan informatif</li>
            </ul>
          </motion.div>
        </div>

        {/* Success Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className="bg-gradient-to-r from-cream-50 to-forest-50 rounded-2xl p-8"
        >
          <h3 className="text-2xl font-bold text-earth-800 mb-6 text-center">
            📊 Success Metrics
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-forest-600 mb-2">
                85%+
              </div>
              <div className="text-sm text-earth-700">Brand Recognition</div>
            </div>
            <div className="bg-white p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-forest-600 mb-2">
                90%+
              </div>
              <div className="text-sm text-earth-700">Design Appeal</div>
            </div>
            <div className="bg-white p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-forest-600 mb-2">
                75%+
              </div>
              <div className="text-sm text-earth-700">Purchase Intent</div>
            </div>
            <div className="bg-white p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-forest-600 mb-2">
                80%+
              </div>
              <div className="text-sm text-earth-700">Premium Perception</div>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );

  // Stage 3: Ideate
  const IdeateStage = () => (
    <motion.div
      variants={stageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="min-h-screen py-16 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-earth-800 mb-6">
            💡 Ideate
          </h2>
          <p className="text-xl text-forest-700 max-w-3xl mx-auto">
            Eksplorasi kreatif melalui moodboard, sketsa, dan konsep visual
            untuk solusi desain
          </p>
        </div>

        {/* Moodboard */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <h3 className="text-2xl font-bold text-earth-800 mb-6 text-center">
            🎨 Moodboard Inspirasi
          </h3>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
            {/* Color Palette */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-earth-600 aspect-square rounded-lg cursor-pointer shadow-lg relative overflow-hidden"
              onClick={() => setSelectedMoodboardItem("earth")}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-earth-400 to-earth-800"></div>
              <div className="absolute bottom-2 left-2 text-white text-xs font-semibold">
                Earth
              </div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-forest-600 aspect-square rounded-lg cursor-pointer shadow-lg relative overflow-hidden"
              onClick={() => setSelectedMoodboardItem("forest")}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-forest-400 to-forest-800"></div>
              <div className="absolute bottom-2 left-2 text-white text-xs font-semibold">
                Forest
              </div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-cream-400 aspect-square rounded-lg cursor-pointer shadow-lg relative overflow-hidden"
              onClick={() => setSelectedMoodboardItem("cream")}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-cream-200 to-cream-600"></div>
              <div className="absolute bottom-2 left-2 text-earth-800 text-xs font-semibold">
                Cream
              </div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="bg-batik-600 aspect-square rounded-lg cursor-pointer shadow-lg relative overflow-hidden"
              onClick={() => setSelectedMoodboardItem("batik")}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-batik-400 to-batik-800"></div>
              <div className="absolute bottom-2 left-2 text-white text-xs font-semibold">
                Batik
              </div>
            </motion.div>

            {/* Textures & Patterns */}
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="aspect-square rounded-lg cursor-pointer shadow-lg bg-cream-100 relative overflow-hidden"
              onClick={() => setSelectedMoodboardItem("goni")}
            >
              <div className="absolute inset-0 bg-pattern-batik"></div>
              <svg className="w-full h-full opacity-30" viewBox="0 0 100 100">
                <defs>
                  <pattern
                    id="goniTexture"
                    x="0"
                    y="0"
                    width="10"
                    height="10"
                    patternUnits="userSpaceOnUse"
                  >
                    <rect width="10" height="10" fill="#d4af7a" />
                    <circle cx="5" cy="5" r="1" fill="#8b7355" />
                  </pattern>
                </defs>
                <rect width="100" height="100" fill="url(#goniTexture)" />
              </svg>
              <div className="absolute bottom-2 left-2 text-earth-800 text-xs font-semibold">
                Goni
              </div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="aspect-square rounded-lg cursor-pointer shadow-lg bg-batik-100 relative overflow-hidden"
              onClick={() => setSelectedMoodboardItem("batikPattern")}
            >
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <defs>
                  <pattern
                    id="batikPattern2"
                    x="0"
                    y="0"
                    width="20"
                    height="20"
                    patternUnits="userSpaceOnUse"
                  >
                    <circle
                      cx="10"
                      cy="10"
                      r="3"
                      fill="#8f662f"
                      opacity="0.4"
                    />
                    <circle cx="5" cy="5" r="2" fill="#a67c3a" opacity="0.6" />
                    <circle
                      cx="15"
                      cy="15"
                      r="2"
                      fill="#a67c3a"
                      opacity="0.6"
                    />
                  </pattern>
                </defs>
                <rect width="100" height="100" fill="url(#batikPattern2)" />
              </svg>
              <div className="absolute bottom-2 left-2 text-white text-xs font-semibold">
                Batik
              </div>
            </motion.div>
          </div>

          {/* Keywords */}
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {[
              "Natural",
              "Etnik",
              "Eco-friendly",
              "Premium",
              "Authentic",
              "Sustainable",
              "Handcraft",
              "Indonesia",
            ].map((keyword) => (
              <motion.div
                key={keyword}
                whileHover={{ scale: 1.1 }}
                className="bg-forest-100 text-forest-800 px-4 py-2 rounded-full font-semibold text-sm shadow-md cursor-pointer"
              >
                {keyword}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Sketches & Concepts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8"
        >
          {/* Logo Sketches */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h4 className="text-xl font-bold text-earth-800 mb-6 text-center">
              ✏️ Sketsa Logo Konsep
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-cream-50 p-4 rounded-lg border-2 border-dashed border-cream-300">
                <svg className="w-full h-24" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="none"
                    stroke="#8f662f"
                    strokeWidth="2"
                  />
                  <path
                    d="M30 50 Q50 30 70 50 Q50 70 30 50"
                    fill="#a67c3a"
                    opacity="0.3"
                  />
                  <rect
                    x="40"
                    y="40"
                    width="20"
                    height="25"
                    fill="#b8934f"
                    rx="2"
                  />
                  <path
                    d="M45 40 Q50 35 55 40"
                    stroke="#856738"
                    strokeWidth="2"
                    fill="none"
                  />
                </svg>
                <p className="text-xs text-center mt-2 text-earth-600">
                  Konsep 1: Leaf + Bag
                </p>
              </div>

              <div className="bg-cream-50 p-4 rounded-lg border-2 border-dashed border-cream-300">
                <svg className="w-full h-24" viewBox="0 0 100 100">
                  <rect
                    x="25"
                    y="25"
                    width="50"
                    height="50"
                    fill="none"
                    stroke="#2e6d37"
                    strokeWidth="2"
                    rx="25"
                  />
                  <circle cx="40" cy="40" r="2" fill="#d3a749" />
                  <circle cx="60" cy="60" r="2" fill="#d3a749" />
                  <rect
                    x="42"
                    y="42"
                    width="16"
                    height="20"
                    fill="#cba872"
                    rx="2"
                  />
                  <line
                    x1="44"
                    y1="45"
                    x2="56"
                    y2="45"
                    stroke="#856738"
                    strokeWidth="1"
                  />
                </svg>
                <p className="text-xs text-center mt-2 text-earth-600">
                  Konsep 2: Circle + Pattern
                </p>
              </div>

              <div className="bg-cream-50 p-4 rounded-lg border-2 border-dashed border-cream-300">
                <svg className="w-full h-24" viewBox="0 0 100 100">
                  <path
                    d="M50 20 L70 40 L70 70 L30 70 L30 40 Z"
                    fill="#5ca66b"
                    opacity="0.4"
                  />
                  <rect
                    x="40"
                    y="45"
                    width="20"
                    height="25"
                    fill="#a17d42"
                    rx="2"
                  />
                  <path
                    d="M45 45 Q50 40 55 45"
                    stroke="#744f28"
                    strokeWidth="2"
                    fill="none"
                  />
                  <line
                    x1="42"
                    y1="55"
                    x2="58"
                    y2="55"
                    stroke="#744f28"
                    strokeWidth="1"
                  />
                </svg>
                <p className="text-xs text-center mt-2 text-earth-600">
                  Konsep 3: Shield + Ethnic
                </p>
              </div>

              <div className="bg-cream-50 p-4 rounded-lg border-2 border-cream-200">
                <SambelilerLogo size="sm" />
                <p className="text-xs text-center mt-2 text-forest-600 font-semibold">
                  ✓ Final Concept
                </p>
              </div>
            </div>
          </div>

          {/* Design Principles */}
          <div className="bg-gradient-to-br from-forest-50 to-earth-50 rounded-2xl p-8">
            <h4 className="text-xl font-bold text-earth-800 mb-6 text-center">
              📐 Prinsip Desain
            </h4>
            <div className="space-y-6">
              <div className="bg-white p-4 rounded-lg shadow">
                <h5 className="font-semibold text-forest-800 mb-2">
                  🎨 Visual Hierarchy
                </h5>
                <p className="text-sm text-forest-700">
                  Logo sebagai focal point, kemudian kemasan, lalu hangtag
                  sebagai supporting element
                </p>
              </div>

              <div className="bg-white p-4 rounded-lg shadow">
                <h5 className="font-semibold text-forest-800 mb-2">
                  🌿 Natural Harmony
                </h5>
                <p className="text-sm text-forest-700">
                  Warna earth tone yang harmonis menciptakan kesan alami dan
                  premium
                </p>
              </div>

              <div className="bg-white p-4 rounded-lg shadow">
                <h5 className="font-semibold text-forest-800 mb-2">
                  🎭 Cultural Balance
                </h5>
                <p className="text-sm text-forest-700">
                  Perpaduan motif tradisional dengan layout modern untuk appeal
                  yang luas
                </p>
              </div>

              <div className="bg-white p-4 rounded-lg shadow">
                <h5 className="font-semibold text-forest-800 mb-2">
                  ♻️ Sustainability Story
                </h5>
                <p className="text-sm text-forest-700">
                  Setiap elemen visual mengkomunikasikan nilai ramah lingkungan
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );

  // Stage 4: Prototype
  const PrototypeStage = () => (
    <motion.div
      variants={stageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="min-h-screen py-16 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-earth-800 mb-6">
            🛠️ Prototype
          </h2>
          <p className="text-xl text-forest-700 max-w-3xl mx-auto">
            Implementasi final dari konsep desain menjadi prototype yang dapat
            diuji dan dievaluasi
          </p>
        </div>

        {/* Logo Final */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <h3 className="text-2xl font-bold text-earth-800 mb-8 text-center">
            🎨 Logo Final & Penjelasan
          </h3>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div className="bg-gradient-to-br from-cream-100 to-cream-200 rounded-2xl p-8 shadow-lg">
              <SambelilerLogo size="xl" />
            </div>

            <div className="space-y-6">
              <div className="bg-white p-6 rounded-xl shadow">
                <h4 className="font-semibold text-earth-800 mb-3 flex items-center">
                  <span className="w-4 h-4 bg-forest-500 rounded-full mr-3"></span>
                  Bentuk & Makna
                </h4>
                <ul className="text-earth-700 space-y-2 text-sm">
                  <li>
                    • <strong>Lingkaran:</strong> Kesatuan dan keberlanjutan
                  </li>
                  <li>
                    • <strong>Daun:</strong> Komitmen terhadap lingkungan
                  </li>
                  <li>
                    • <strong>Tas:</strong> Produk utama dengan detail authentic
                  </li>
                  <li>
                    • <strong>Motif Batik:</strong> Identitas budaya Indonesia
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-xl shadow">
                <h4 className="font-semibold text-earth-800 mb-3 flex items-center">
                  <span className="w-4 h-4 bg-earth-500 rounded-full mr-3"></span>
                  Warna & Psikologi
                </h4>
                <ul className="text-earth-700 space-y-2 text-sm">
                  <li>
                    • <strong>Earth Brown:</strong> Stabilitas, kepercayaan,
                    tradisional
                  </li>
                  <li>
                    • <strong>Forest Green:</strong> Keberlanjutan, kesegaran,
                    organic
                  </li>
                  <li>
                    • <strong>Cream:</strong> Elegance, kemurnian, premium
                  </li>
                  <li>
                    • <strong>Batik Gold:</strong> Kemewahan, warisan budaya
                  </li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-xl shadow">
                <h4 className="font-semibold text-earth-800 mb-3 flex items-center">
                  <span className="w-4 h-4 bg-batik-500 rounded-full mr-3"></span>
                  Aplikasi & Fleksibilitas
                </h4>
                <ul className="text-earth-700 space-y-2 text-sm">
                  <li>• Scalable dari bisnis card hingga billboard</li>
                  <li>• Readable di print maupun digital</li>
                  <li>• Monochrome version untuk aplikasi terbatas</li>
                  <li>• Mudah diaplikasikan di berbagai material</li>
                </ul>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Packaging Mockup */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-16"
        >
          <h3 className="text-2xl font-bold text-earth-800 mb-8 text-center">
            📦 Mockup Kemasan Premium
          </h3>
          <PackagingMockup />
        </motion.section>

        {/* Hangtag Details */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <h3 className="text-2xl font-bold text-earth-800 mb-8 text-center">
            🏷️ Hangtag dengan Instruksi Perawatan
          </h3>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Hangtag Visual */}
            <div className="bg-gradient-to-br from-cream-100 to-cream-200 rounded-2xl p-8 flex items-center justify-center">
              <div className="bg-white rounded-lg shadow-lg p-6 w-64 h-80 relative">
                {/* Hangtag hole */}
                <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-6 h-6 border-4 border-earth-400 rounded-full bg-cream-50"></div>

                {/* Header */}
                <div className="text-center mb-4 pt-4">
                  <div className="w-12 h-8 bg-earth-600 rounded mx-auto mb-2 flex items-center justify-center">
                    <span className="text-white text-xs font-bold">S</span>
                  </div>
                  <h4 className="text-sm font-bold text-earth-800">
                    SAMBELILER
                  </h4>
                  <p className="text-xs text-forest-600">Tas Etnik Indonesia</p>
                </div>

                {/* Care Instructions */}
                <div className="space-y-3 text-xs text-earth-700">
                  <div className="border-b border-cream-300 pb-2">
                    <h5 className="font-semibold mb-1">Petunjuk Perawatan:</h5>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-start space-x-2">
                      <span className="text-forest-600 font-bold">1.</span>
                      <span>Hindari air berlebihan</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <span className="text-forest-600 font-bold">2.</span>
                      <span>Bersihkan dengan kain lembab</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <span className="text-forest-600 font-bold">3.</span>
                      <span>Simpan di tempat kering</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <span className="text-forest-600 font-bold">4.</span>
                      <span>Gunakan silica gel</span>
                    </div>
                  </div>

                  <div className="border-t border-cream-300 pt-2 mt-4">
                    <p className="text-center text-forest-600 font-medium">
                      🌿 Eco-friendly Product
                    </p>
                    <p className="text-center text-xs mt-1">
                      Dukung UMKM Indonesia
                    </p>
                  </div>
                </div>

                {/* QR Code placeholder */}
                <div className="absolute bottom-4 right-4 w-8 h-8 bg-earth-200 rounded border">
                  <div
                    className="w-full h-full bg-earth-600 rounded"
                    style={{
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Crect width='1' height='1' fill='%23fff'/%3E%3Crect x='2' width='1' height='1' fill='%23fff'/%3E%3Crect x='4' width='1' height='1' fill='%23fff'/%3E%3C/svg%3E")`,
                      backgroundSize: "4px 4px",
                    }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Hangtag Benefits */}
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-xl shadow">
                <h4 className="font-semibold text-earth-800 mb-3">
                  💡 Manfaat Hangtag
                </h4>
                <ul className="text-earth-700 space-y-2 text-sm">
                  <li>• Edukasi konsumen tentang perawatan produk</li>
                  <li>• Meningkatkan customer satisfaction</li>
                  <li>• Memperpanjang umur produk</li>
                  <li>• Membangun trust dan profesionalisme</li>
                  <li>• Digital engagement melalui QR code</li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-xl shadow">
                <h4 className="font-semibold text-earth-800 mb-3">
                  📱 Digital Integration
                </h4>
                <ul className="text-earth-700 space-y-2 text-sm">
                  <li>• QR code mengarah ke video perawatan</li>
                  <li>• Link ke social media dan community</li>
                  <li>• Product authentication</li>
                  <li>• Customer feedback collection</li>
                  <li>• Loyalty program registration</li>
                </ul>
              </div>

              <div className="bg-white p-6 rounded-xl shadow">
                <h4 className="font-semibold text-earth-800 mb-3">
                  🌍 Sustainability Message
                </h4>
                <ul className="text-earth-700 space-y-2 text-sm">
                  <li>• Material hangtag: Recycled paper</li>
                  <li>• Eco-friendly ink</li>
                  <li>• Biodegradable coating</li>
                  <li>• Messaging tentang environmental impact</li>
                  <li>• Tips sustainable usage</li>
                </ul>
              </div>
            </div>
          </div>
        </motion.section>
      </div>
    </motion.div>
  );

  // Stage 5: Test
  const TestStage = () => (
    <motion.div
      variants={stageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="min-h-screen py-16 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-earth-800 mb-6">
            🧪 Test
          </h2>
          <p className="text-xl text-forest-700 max-w-3xl mx-auto">
            Simulasi digital untuk menguji respons pengguna terhadap prototype
            yang telah dibuat
          </p>
        </div>

        <TestingInterface />
      </div>
    </motion.div>
  );

  return (
    <AnimatePresence mode="wait">
      {currentStage === 0 && <EmpathizeStage key="empathize" />}
      {currentStage === 1 && <DefineStage key="define" />}
      {currentStage === 2 && <IdeateStage key="ideate" />}
      {currentStage === 3 && <PrototypeStage key="prototype" />}
      {currentStage === 4 && <TestStage key="test" />}
    </AnimatePresence>
  );
};

export default DesignThinkingStages;
