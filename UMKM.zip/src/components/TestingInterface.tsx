import React, { useState } from "react";
import { motion } from "framer-motion";

const TestingInterface: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);

  const questions = [
    {
      id: 0,
      question: "Bagaimana kesan pertama Anda terhadap logo Sambeliler?",
      type: "rating",
      options: [
        "Sangat menarik",
        "Menarik",
        "Biasa saja",
        "Kurang menarik",
        "Tidak menarik",
      ],
    },
    {
      id: 1,
      question:
        "Apakah desain kemasan produk terlihat premium dan ramah lingkungan?",
      type: "rating",
      options: [
        "Sangat setuju",
        "Setuju",
        "Netral",
        "Kurang setuju",
        "Tidak setuju",
      ],
    },
    {
      id: 2,
      question: "Seberapa tertarik Anda untuk membeli produk tas Sambeliler?",
      type: "rating",
      options: [
        "Sangat tertarik",
        "Tertarik",
        "Mungkin",
        "Kurang tertarik",
        "Tidak tertarik",
      ],
    },
    {
      id: 3,
      question: "Menurut Anda, berapa harga yang pantas untuk tas Sambeliler?",
      type: "price",
      options: [
        "Rp 50.000 - Rp 100.000",
        "Rp 100.000 - Rp 200.000",
        "Rp 200.000 - Rp 300.000",
        "Rp 300.000 - Rp 500.000",
        "Di atas Rp 500.000",
      ],
    },
    {
      id: 4,
      question: "Apa yang paling menarik dari brand Sambeliler bagi Anda?",
      type: "multiple",
      options: [
        "Desain logo yang etnik",
        "Kemasan ramah lingkungan",
        "Kualitas bahan goni",
        "Motif batik/lurik/tenun",
        "Mendukung UMKM Indonesia",
      ],
    },
  ];

  const handleAnswer = (answer: string) => {
    setAnswers((prev) => ({ ...prev, [currentQuestion]: answer }));

    if (currentQuestion < questions.length - 1) {
      setTimeout(() => {
        setCurrentQuestion(currentQuestion + 1);
      }, 500);
    } else {
      setTimeout(() => {
        setShowResults(true);
      }, 500);
    }
  };

  const resetTest = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
  };

  const getResultsAnalysis = () => {
    const logoRating = answers[0];
    const packagingRating = answers[1];
    const purchaseIntent = answers[2];

    if (
      logoRating === "Sangat menarik" &&
      packagingRating === "Sangat setuju" &&
      purchaseIntent === "Sangat tertarik"
    ) {
      return {
        title: "Feedback Luar Biasa! 🎉",
        description:
          "Brand Sambeliler mendapat respon sangat positif! Desain logo dan kemasan sudah sangat sesuai dengan target pasar.",
        color: "forest",
      };
    } else if (
      (logoRating === "Menarik" || logoRating === "Sangat menarik") &&
      purchaseIntent !== "Tidak tertarik"
    ) {
      return {
        title: "Feedback Positif! ✨",
        description:
          "Brand Sambeliler cukup menarik minat konsumen. Ada beberapa area yang bisa diperbaiki untuk hasil optimal.",
        color: "earth",
      };
    } else {
      return {
        title: "Perlu Perbaikan 💪",
        description:
          "Brand Sambeliler memiliki potensi, namun perlu beberapa penyesuaian untuk meningkatkan daya tarik konsumen.",
        color: "batik",
      };
    }
  };

  if (showResults) {
    const analysis = getResultsAnalysis();

    return (
      <div className="max-w-4xl mx-auto p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-earth-800 mb-4">
            Hasil Testing Brand Sambeliler
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`bg-${analysis.color}-50 border-2 border-${analysis.color}-200 rounded-xl p-8 mb-8`}
        >
          <h3
            className={`text-2xl font-bold text-${analysis.color}-800 mb-4 text-center`}
          >
            {analysis.title}
          </h3>
          <p className={`text-${analysis.color}-700 text-center text-lg mb-6`}>
            {analysis.description}
          </p>

          {/* Results breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h4 className="font-semibold text-earth-800 mb-4">
                Ringkasan Jawaban:
              </h4>
              <div className="space-y-3">
                {questions.map((q, index) => (
                  <div key={index} className="border-b border-gray-100 pb-2">
                    <p className="text-sm text-gray-600 mb-1">{q.question}</p>
                    <p className="font-medium text-earth-700">
                      {answers[index] || "Tidak dijawab"}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h4 className="font-semibold text-earth-800 mb-4">
                Rekomendasi:
              </h4>
              <ul className="space-y-2 text-earth-700">
                <li>• Pertahankan elemen desain yang sudah baik</li>
                <li>• Fokus pada komunikasi nilai ramah lingkungan</li>
                <li>• Tingkatkan awareness tentang kualitas produk</li>
                <li>• Kembangkan strategi pricing yang kompetitif</li>
                <li>• Perkuat storytelling tentang UMKM Indonesia</li>
              </ul>
            </div>
          </div>
        </motion.div>

        <div className="text-center">
          <motion.button
            onClick={resetTest}
            className="bg-forest-600 hover:bg-forest-700 text-white px-8 py-3 rounded-lg font-semibold shadow-lg transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Ulangi Testing
          </motion.button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl md:text-4xl font-bold text-earth-800 mb-4">
          Testing Interface Brand Sambeliler
        </h2>
        <p className="text-lg text-forest-700 max-w-2xl mx-auto">
          Bantu kami mengevaluasi desain brand Sambeliler dengan menjawab
          beberapa pertanyaan berikut
        </p>
      </div>

      {/* Progress bar */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-forest-600">Progress</span>
          <span className="text-sm text-forest-600">
            {currentQuestion + 1} dari {questions.length}
          </span>
        </div>
        <div className="w-full bg-cream-200 rounded-full h-2">
          <motion.div
            className="bg-forest-500 h-2 rounded-full"
            initial={{ width: 0 }}
            animate={{
              width: `${((currentQuestion + 1) / questions.length) * 100}%`,
            }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      {/* Current question */}
      <motion.div
        key={currentQuestion}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        className="bg-white rounded-xl shadow-lg p-8 mb-8"
      >
        <h3 className="text-xl md:text-2xl font-semibold text-earth-800 mb-6 text-center">
          {questions[currentQuestion].question}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {questions[currentQuestion].options.map((option, index) => (
            <motion.button
              key={index}
              onClick={() => handleAnswer(option)}
              className="p-4 bg-cream-50 hover:bg-forest-50 border-2 border-cream-200 hover:border-forest-300 rounded-lg text-earth-700 font-medium transition-all duration-200 text-left"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {option}
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Quick action buttons */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.button
          className="bg-earth-600 hover:bg-earth-700 text-white p-4 rounded-lg font-semibold shadow transition-colors"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        >
          📱 Lihat Logo
        </motion.button>

        <motion.button
          className="bg-forest-600 hover:bg-forest-700 text-white p-4 rounded-lg font-semibold shadow transition-colors"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => {
            const packagingSection =
              document.getElementById("packaging-section");
            packagingSection?.scrollIntoView({ behavior: "smooth" });
          }}
        >
          <p>🏷️ Baca Hangtag</p>
        </motion.button>

        <motion.button
          className="bg-batik-600 hover:bg-batik-700 text-white p-4 rounded-lg font-semibold shadow transition-colors"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => {
            const feedbackSection = document.getElementById("feedback-section");
            feedbackSection?.scrollIntoView({ behavior: "smooth" });
          }}
        >
          💬 Feedback
        </motion.button>
      </div>
    </div>
  );
};

export default TestingInterface;
