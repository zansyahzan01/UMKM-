import React from "react";

interface SambelilerLogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

const SambelilerLogo: React.FC<SambelilerLogoProps> = ({
  size = "md",
  className = "",
}) => {
  const sizeClasses = {
    sm: "w-24 h-24",
    md: "w-32 h-32",
    lg: "w-48 h-48",
    xl: "w-64 h-64",
  };

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <svg
        className={`${sizeClasses[size]} mb-4`}
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Background circle with natural texture */}
        <circle
          cx="100"
          cy="100"
          r="95"
          fill="#f1f8f0"
          stroke="#3e8749"
          strokeWidth="2"
        />

        {/* Batik pattern elements */}
        <defs>
          <pattern
            id="batikPattern"
            x="0"
            y="0"
            width="20"
            height="20"
            patternUnits="userSpaceOnUse"
          >
            <circle cx="10" cy="10" r="1.5" fill="#a67c3a" opacity="0.3" />
            <circle cx="5" cy="5" r="1" fill="#b8934f" opacity="0.4" />
            <circle cx="15" cy="15" r="1" fill="#b8934f" opacity="0.4" />
          </pattern>
        </defs>

        {/* Main leaf/bag shape */}
        <path
          d="M100 40 C130 50, 150 80, 140 110 C135 130, 120 140, 100 145 C80 140, 65 130, 60 110 C50 80, 70 50, 100 40 Z"
          fill="url(#batikPattern)"
          stroke="#2e6d37"
          strokeWidth="2"
        />

        {/* Central bag silhouette */}
        <path
          d="M85 70 L115 70 C118 70, 120 72, 120 75 L120 120 C120 125, 115 130, 110 130 L90 130 C85 130, 80 125, 80 120 L80 75 C80 72, 82 70, 85 70 Z"
          fill="#cba872"
          stroke="#856738"
          strokeWidth="1.5"
        />

        {/* Bag handles */}
        <path
          d="M90 70 C90 65, 95 60, 100 60 C105 60, 110 65, 110 70"
          stroke="#856738"
          strokeWidth="3"
          fill="none"
        />

        {/* Decorative lurik stripes */}
        <rect
          x="82"
          y="85"
          width="36"
          height="2"
          fill="#a17d42"
          opacity="0.7"
        />
        <rect
          x="82"
          y="95"
          width="36"
          height="2"
          fill="#a17d42"
          opacity="0.7"
        />
        <rect
          x="82"
          y="105"
          width="36"
          height="2"
          fill="#a17d42"
          opacity="0.7"
        />
        <rect
          x="82"
          y="115"
          width="36"
          height="2"
          fill="#a17d42"
          opacity="0.7"
        />

        {/* Decorative leaves */}
        <path
          d="M60 60 C55 65, 55 75, 60 80 C65 75, 65 65, 60 60"
          fill="#5ca66b"
        />
        <path
          d="M140 60 C145 65, 145 75, 140 80 C135 75, 135 65, 140 60"
          fill="#5ca66b"
        />

        {/* Traditional ornaments */}
        <circle cx="70" cy="90" r="3" fill="#d3a749" opacity="0.8" />
        <circle cx="130" cy="110" r="3" fill="#d3a749" opacity="0.8" />

        {/* Tenun weave pattern */}
        <g opacity="0.4">
          <line
            x1="85"
            y1="75"
            x2="115"
            y2="75"
            stroke="#744f28"
            strokeWidth="0.5"
          />
          <line
            x1="85"
            y1="80"
            x2="115"
            y2="80"
            stroke="#744f28"
            strokeWidth="0.5"
          />
          <line
            x1="90"
            y1="70"
            x2="90"
            y2="130"
            stroke="#744f28"
            strokeWidth="0.5"
          />
          <line
            x1="100"
            y1="70"
            x2="100"
            y2="130"
            stroke="#744f28"
            strokeWidth="0.5"
          />
          <line
            x1="110"
            y1="70"
            x2="110"
            y2="130"
            stroke="#744f28"
            strokeWidth="0.5"
          />
        </g>
      </svg>

      {/* Brand text */}
      <div className="text-center">
        <h1
          className="text-2xl md:text-3xl lg:text-4xl font-bold text-earth-800 mb-1"
          style={{ fontFamily: "serif" }}
        >
          Sambeliler
        </h1>
        <p className="text-sm md:text-base text-forest-600 font-medium tracking-wide">
          Tas Etnik Indonesia
        </p>
        <div className="mt-2 h-1 w-16 bg-gradient-to-r from-earth-500 to-forest-500 rounded-full mx-auto"></div>
      </div>
    </div>
  );
};

export default SambelilerLogo;
