import React, { useState } from "react";
import { motion } from "framer-motion";
import SambelilerLogo from "@/components/SambelilerLogo";
import PackagingMockup from "@/components/PackagingMockup";
import TestingInterface from "@/components/TestingInterface";
import DesignThinkingStages from "@/components/DesignThinkingStages";

const Index = () => {
  const [currentStage, setCurrentStage] = useState(0);

  const stages = ["Empathize", "Define", "Ideate", "Prototype", "Test"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-cream-50 via-cream-100 to-forest-50">
      {/* Header with Design Thinking Navigation */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-sm border-b border-cream-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-forest-100 rounded-full flex items-center justify-center">
                <p>🛍️</p>
              </div>
              <div>
                <h1 className="text-xl font-bold text-earth-800">
                  Sambeliler Design Thinking
                </h1>
                <p className="text-sm text-forest-600">
                  Prototype Branding UMKM Indonesia
                </p>
              </div>
            </div>

            {/* Stage Navigation */}
            <nav className="hidden md:flex space-x-1">
              {stages.map((stage, index) => (
                <button
                  key={stage}
                  onClick={() => setCurrentStage(index)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    currentStage === index
                      ? "bg-forest-600 text-white shadow-lg"
                      : "bg-cream-100 text-earth-700 hover:bg-cream-200"
                  }`}
                >
                  {index + 1}. {stage}
                </button>
              ))}
            </nav>
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden mt-4">
            <div className="flex space-x-2 overflow-x-auto pb-2">
              {stages.map((stage, index) => (
                <button
                  key={stage}
                  onClick={() => setCurrentStage(index)}
                  className={`px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                    currentStage === index
                      ? "bg-forest-600 text-white"
                      : "bg-cream-100 text-earth-700"
                  }`}
                >
                  {index + 1}. {stage}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative">
        <DesignThinkingStages currentStage={currentStage} />
      </main>

      {/* Progress Indicator */}
      <div className="fixed bottom-6 right-6 bg-white rounded-full shadow-lg p-4 z-40">
        <div className="text-center">
          <div className="text-2xl font-bold text-forest-600">
            {currentStage + 1}/5
          </div>
          <div className="text-xs text-earth-600 mt-1">
            {stages[currentStage]}
          </div>
        </div>
      </div>

      {/* Navigation Controls */}
      <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-4 z-40">
        <motion.button
          onClick={() => setCurrentStage(Math.max(0, currentStage - 1))}
          disabled={currentStage === 0}
          className={`px-6 py-3 rounded-full font-semibold shadow-lg transition-all ${
            currentStage === 0
              ? "bg-gray-300 text-gray-500 cursor-not-allowed"
              : "bg-earth-600 hover:bg-earth-700 text-white"
          }`}
          whileHover={currentStage > 0 ? { scale: 1.05 } : {}}
          whileTap={currentStage > 0 ? { scale: 0.95 } : {}}
        >
          ← Previous
        </motion.button>

        <motion.button
          onClick={() => setCurrentStage(Math.min(4, currentStage + 1))}
          disabled={currentStage === 4}
          className={`px-6 py-3 rounded-full font-semibold shadow-lg transition-all ${
            currentStage === 4
              ? "bg-gray-300 text-gray-500 cursor-not-allowed"
              : "bg-forest-600 hover:bg-forest-700 text-white"
          }`}
          whileHover={currentStage < 4 ? { scale: 1.05 } : {}}
          whileTap={currentStage < 4 ? { scale: 0.95 } : {}}
        >
          Next →
        </motion.button>
      </div>
    </div>
  );
};

export default Index;
